package pruebaPracticaUD1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaPracticaUd1Application {

	public static void main(String[] args) {
		SpringApplication.run(PruebaPracticaUd1Application.class, args);
	}

}
