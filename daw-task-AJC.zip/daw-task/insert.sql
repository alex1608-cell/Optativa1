INSERT INTO tu_tabla (descripcion, estado, fecha_creacion, fecha_vencimiento, titulo)
VALUES
('Preparar informe mensual de ventas', 'EN_PROGRESO', '2025-10-10', '2025-10-25', 'Informe de ventas'),
('Actualizar base de datos de clientes', 'PENDIENTE', '2025-10-18', '2025-10-30', 'Actualización clientes'),
('Diseñar nuevo logotipo', 'COMPLETADO', '2025-09-01', '2025-09-15', 'Diseño gráfico'),
('Revisar políticas de seguridad', 'PENDIENTE', '2025-10-19', '2025-11-01', 'Seguridad interna'),
('Implementar copias de seguridad automáticas', 'EN_PROGRESO', '2025-10-05', '2025-10-28', 'Backup automático');
