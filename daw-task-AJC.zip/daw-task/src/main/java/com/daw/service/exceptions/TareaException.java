package com.daw.service.exceptions;

public class TareaException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3780729160062675958L;

	public TareaException(String message) {
		super(message);
	}

	
}
