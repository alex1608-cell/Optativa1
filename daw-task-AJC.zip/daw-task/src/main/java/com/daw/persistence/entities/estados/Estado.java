package com.daw.persistence.entities.estados;

public enum Estado {

	PENDIENTE, EN_PROGRESO, COMPLETADO
}
